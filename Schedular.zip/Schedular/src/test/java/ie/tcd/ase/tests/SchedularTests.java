package ie.tcd.ase.tests;

import static org.junit.Assert.*;

import java.net.InetAddress;
import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ie.tcd.ase.controller.Schedular;
import ie.tcd.ase.entity.Schedule;
import ie.tcd.ase.entity.Trip;
import ie.tcd.ase.service.ScheduleService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:spring/*.xml")
public class SchedularTests {
	@Autowired
	ScheduleService scheduleService;
	
	@Test
	public void testSimilarPositive() {
		Date date1=new Date();
		
		Schedule schedule1=new Schedule();
		schedule1.setCommuteType(1);
		schedule1.setStartDuration(date1);
		schedule1.setStartPosition("Trinity");
		
		Schedule schedule2=new Schedule();
		schedule2.setCommuteType(1);
		schedule2.setStartDuration(date1);
		schedule2.setStartPosition("trinity");
		
		boolean result=new Schedular().similar(schedule1, schedule2);
		assertTrue(result);
	}
	
	@Test
	public void testSimilarNegative1() {
		Date date1=new Date();
		Date date2=new Date();
		date2.setDate(date2.getDate()+1);
		
		Schedule schedule1=new Schedule();
		schedule1.setCommuteType(1);
		schedule1.setStartDuration(date1);
		schedule1.setStartPosition("Trinity");
		
		Schedule schedule2=new Schedule();
		schedule2.setCommuteType(1);
		schedule2.setStartDuration(date2);
		schedule2.setStartPosition("Trinity");
		
		boolean result=new Schedular().similar(schedule1, schedule2);
		assertFalse(result);
	}
	
	@Test
	public void testSimilarNegative2() {
		Date date1=new Date();
		Date date2=new Date();
		date2.setMonth(date2.getMonth()+1);
		
		Schedule schedule1=new Schedule();
		schedule1.setCommuteType(1);
		schedule1.setStartDuration(date1);
		schedule1.setStartPosition("Trinity");
		
		Schedule schedule2=new Schedule();
		schedule2.setCommuteType(1);
		schedule2.setStartDuration(date2);
		schedule2.setStartPosition("Trinity");
		
		boolean result=new Schedular().similar(schedule1, schedule2);
		assertFalse(result);
	}
	
	@Test
	public void testSimilarNegative3() {
		Date date1=new Date();
		Date date2=new Date();
		date2.setYear(date2.getYear()+1);
		
		Schedule schedule1=new Schedule();
		schedule1.setCommuteType(1);
		schedule1.setStartDuration(date1);
		schedule1.setStartPosition("Trinity");
		
		Schedule schedule2=new Schedule();
		schedule2.setCommuteType(1);
		schedule2.setStartDuration(date2);
		schedule2.setStartPosition("Trinity");
		
		boolean result=new Schedular().similar(schedule1, schedule2);
		assertFalse(result);
	}
	
	@Test
	public void testSimilarNegative4() {
		Date date1=new Date();
		Date date2=new Date();
		date2.setMonth(date2.getMonth()+1);
		
		Schedule schedule1=new Schedule();
		schedule1.setCommuteType(1);
		schedule1.setStartDuration(date1);
		schedule1.setStartPosition("Trinity");
		
		Schedule schedule2=new Schedule();
		schedule2.setCommuteType(0);
		schedule2.setStartDuration(date2);
		schedule2.setStartPosition("Trinity");
		
		boolean result=new Schedular().similar(schedule1, schedule2);
		assertFalse(result);
	}
	
	@Test
	public void testSimilarNegative5() {
		Date date1=new Date();
		
		Schedule schedule1=new Schedule();
		schedule1.setCommuteType(1);
		schedule1.setStartDuration(date1);
		schedule1.setStartPosition("Trinity");
		
		Schedule schedule2=new Schedule();
		schedule2.setCommuteType(1);
		schedule2.setStartDuration(date1);
		schedule2.setStartPosition("Trinity College");
		
		boolean result=new Schedular().similar(schedule1, schedule2);
		assertFalse(result);
	}
}
