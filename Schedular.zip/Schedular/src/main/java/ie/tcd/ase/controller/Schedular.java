package ie.tcd.ase.controller;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.apache.commons.collections.map.HashedMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ie.tcd.ase.entity.Schedule;
import ie.tcd.ase.entity.Trip;
import ie.tcd.ase.service.ScheduleService;

public class Schedular implements Runnable {
	ScheduleService scheduleService;
	int timeout;
	String threadName;
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	public Schedular() {
	}
	
	public Schedular(ScheduleService scheduleService, String threadName,int timeout) {
		super();
		this.scheduleService = scheduleService;
		this.threadName=threadName;
		this.timeout=timeout;
		
		logger.info("Schedular Object created:\nthreadname: "+threadName+", timeout: "+timeout);
	}
	
	@Override
	public void run() {
        System.out.println("starting schedular with timeout period "+timeout+" seconds");
        logger.info("starting schedular with timeout period "+timeout+" seconds");
        
        Thread.currentThread().setName(threadName);
        
        try {
        	while(true) {
		        System.out.println("schedular thread with name: "+ Thread.currentThread().getName()+" woke up ");
		        logger.info("schedular thread with name: "+ Thread.currentThread().getName()+" woke up ");
		        
		        scheduleTrip();
		        
		        Thread.sleep(timeout*1000);
			} 
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void scheduleTrip() {
		List<Schedule> listSchedule=scheduleService.getSchedule(0);
        System.out.println("Schedule list size: "+listSchedule.size());
        logger.info("Schedule list size: "+listSchedule.size());
        
        Map<Integer,Group> groups=new HashedMap();
		Set<Schedule> schedulesProcessed=new HashSet<Schedule>();
		Random random=new Random();
		
		for(int i=0;i<listSchedule.size();i++) {
			Schedule currentSchedule=listSchedule.get(i);
			//skip if trip is already formed for this schedule
			if(schedulesProcessed.contains(currentSchedule)) continue;
			
			Set<Schedule> currentSchedulesProcessed=new HashSet<Schedule>();
			
			for(int j=i+1, groupMembers=0;j<listSchedule.size();j++) {
				Schedule anotherSchedule=listSchedule.get(j);
				if(similar(currentSchedule,anotherSchedule)) {
					currentSchedulesProcessed.add(anotherSchedule);
					currentSchedulesProcessed.add(currentSchedule);
					
					groupMembers++;
				}
				//maximum 2 group members for now
				if(groupMembers==2) break;
			}
			
			if(currentSchedulesProcessed.size()!=0) {
				schedulesProcessed.addAll(currentSchedulesProcessed);
				
				int groupId=random.nextInt();
				if(groupId<0) groupId*=-1;
				Group group=new Group();
				group.setGroupMembers(currentSchedulesProcessed);
				
				for(Schedule schedule: currentSchedulesProcessed) {
					group.setStartPosition(schedule.getStartPosition());
					group.setStartTime("09:00");
					//group.setStartTime(schedule.getStartDuration());
					break;
				}
				
				groups.put(groupId, group);
			}
			//to simulate different threads working, break here after forming groups
			break;
		}
		
		System.out.println("#################Groups formed##################");
		logger.info("#################Groups formed##################");
		for(Integer groupId:groups.keySet()) {
        	System.out.println("GroupId: "+groupId);
        	System.out.println("Group Members: "+groups.get(groupId));
        }
        System.out.println("#################Groups ends##################");
        logger.info("#################Groups ends##################");
        
		//update matched schedule's status to success
		updateScheduleStatusToSuccess(schedulesProcessed);
		
        //write trips to Trip table
        writeTripsData(groups);
	}


	public boolean similar(Schedule currentSchedule, Schedule anotherSchedule) {
		if(currentSchedule.getCommuteType()!=anotherSchedule.getCommuteType()) return false;
		//if(currentSchedule.getStartDuration().getDate() !=anotherSchedule.getStartDuration().getDate()) return false;
		//if(currentSchedule.getStartDuration().getMonth() !=anotherSchedule.getStartDuration().getMonth()) return false;
		//if(currentSchedule.getStartDuration().getYear() !=anotherSchedule.getStartDuration().getYear()) return false;
		if(! currentSchedule.getScheduleDateTime().equals(anotherSchedule.getScheduleDateTime())) return false;
		if(! currentSchedule.getStartPosition().toLowerCase().equals(anotherSchedule.getStartPosition().toLowerCase())) return false;
		return true;
	}
	
	public void updateScheduleStatusToSuccess(Set<Schedule> tripDone) {
		try {
			for(Schedule schedule:tripDone) {
				schedule.setStatus(1);//1 for done for both columns
				String servername="Server: "+InetAddress.getLocalHost().getHostName()+"-Thread: "+threadName;
				schedule.setCurrentServer(servername);
				scheduleService.updateScheduleToSuccess(schedule);
			}
		}catch(Exception e) {e.printStackTrace();}
	}
	
	public void writeTripsData(Map<Integer,Group> groups) {
		for(Integer groupId:groups.keySet()) {
			Group group= groups.get(groupId);
			for(Schedule schedule:group.getGroupMembers()) {
				Trip trip=new Trip();
				trip.setGroupId(groupId);
				trip.setScheduleId(schedule.getId());
				trip.setStatus(1);//1 for done for both columns
				trip.setWeekday(schedule.getWeekday());
				trip.setStartPosition(group.getStartPosition());

				scheduleService.saveTrip(trip);
			}
		}
	}
}
