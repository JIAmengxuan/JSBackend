TCD.ASE.Group7
JourneySharing backend part.

--local--
http://localhost:8080/Schedular/controller/hello
http://localhost:8080/Schedular/controller/enterDummyData
http://localhost:8080/Schedular/controller/startSchedular/thread2/13

--schedular1--
http://35.243.187.7:8080/Schedular/controller/hello
http://35.243.187.7:8080/Schedular/controller/enterDummyData
http://35.243.187.7:8080/Schedular/controller/startSchedular/thread2/13

--schedular2--
http://35.196.44.56:8080/Schedular/controller/hello
http://35.196.44.56:8080/Schedular/controller/enterDummyData
http://35.196.44.56:8080/Schedular/controller/startSchedular/thread2/13

--mysql--
mysql -u group7user1 -h 35.241.150.114 -p

--select commands--
select id,user_id,start_position,end_position,weekday,start_duration,gender_preference,rating_preference,commute_type,status,current_server from schedule;
select * from trip;

group7password1



apache/apache-tomcat-8.5.39
cd apache/apache-tomcat-8.5.39/bin
cd apache/apache-tomcat-8.5.39/webapps
mv Schedular.war apache/apache-tomcat-8.5.39/webapps