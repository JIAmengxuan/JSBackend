package ie.tcd.ase.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MyClass {

	public static void main(String[] args) {
		//resetDatabase();
		resetSchedules();
	}
	
	public static void reset() {
		//resetDatabase();
		resetSchedules();
	}
	
	private static void resetSchedules() {
		try
        {
            Class.forName( "com.mysql.jdbc.Driver" ).newInstance();
            try
            {	
                //Connection con = DriverManager.getConnection( "jdbc:mysql://localhost/soup", "root", "secret" );
                Connection con = DriverManager.getConnection( "jdbc:mysql://remotemysql.com:3306/8oH3q0Co0R", "8oH3q0Co0R", "2vbqKcbstv" );
                try
                {
                    Statement statement = con.createStatement();
                    //drop all tables
                    statement.execute("delete from trip");
                    statement.execute("delete from schedule");
                    
                    System.out.println("schedule and trip data reset");
                    statement.close();
                }
                catch ( SQLException e )
                {
                    System.out.println( "JDBC error: " + e );
                }
                finally
                {
                    con.close();
                }
            }
            catch( SQLException e )
            {
                System.out.println( "could not get JDBC connection: " + e );
            }
        }
        catch( Exception e )
        {
            System.out.println( "could not load JDBC driver: " + e );
        }
	}

	private static void resetDatabase() {
		try
        {
            Class.forName( "com.mysql.jdbc.Driver" ).newInstance();
            try
            {	
                //Connection con = DriverManager.getConnection( "jdbc:mysql://localhost/soup", "root", "secret" );
                Connection con = DriverManager.getConnection( "jdbc:mysql://remotemysql.com:3306/8oH3q0Co0R", "8oH3q0Co0R", "2vbqKcbstv" );
                try
                {
                	System.out.println("2");
                    Statement statement = con.createStatement();
                    
                    
                    //drop all tables
                    statement.execute("DROP TABLE IF EXISTS login_info");
                    statement.execute("DROP TABLE IF EXISTS rating");
                    statement.execute("DROP TABLE IF EXISTS trip");
                    statement.execute("DROP TABLE IF EXISTS schedule");
                    statement.execute("DROP TABLE IF EXISTS user_info");
                    
                    
                    System.out.println("all tables dropped");
                    
                    statement.execute("create table user_info (\n" + 
                    		"    `id` int not null auto_increment,\n" + 
                    		"    `create_date` DATE not null,\n" + 
                    		"    `update_date` date not null,\n" + 
                    		"    `create_by` varchar (100) not null default 'sys',\n" + 
                    		"    `update_by` varchar (100) not null default 'sys',\n" + 
                    		"    `user_name` varchar (100) not null,\n" + 
                    		"    `gender` varchar (1) not  null comment '1.female 2.male',\n" + 
                    		"    `email` varchar (100),\n" + 
                    		"    `phone_number` int not null,\n" + 
                    		"    primary key (id)\n" + 
                    		")ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='user_ifo table';");
                    
                    statement.execute("create table login_info (\n" + 
                    		"    `id` int not null auto_increment,\n" + 
                    		"    `create_date` DATE not null ,\n" + 
                    		"    `update_date` date not null ,\n" + 
                    		"    `create_by` varchar (100) not null default 'sys',\n" + 
                    		"    `update_by` varchar (100) not null default 'sys',\n" + 
                    		"    `user_id` int not null comment 'id of table user_info',\n" + 
                    		"    `user_status` int comment '1.active 2.inactive',\n" + 
                    		"    `password33` varchar(100) not null ,\n" + 
                    		"    `authorization_token` int not null,\n" + 
                    		"    primary key (id),\n" + 
                    		"    constraint login_FK foreign key (`user_id`) references `user_info` (`id`)\n" + 
                    		")ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='login_info table';");
                    
                    statement.execute("create table rating(\n" + 
                    		"    `id` int not null auto_increment,\n" + 
                    		"    `create_date` DATE not null ,\n" + 
                    		"    `update_date` date not null ,\n" + 
                    		"    `create_by` varchar (100) not null default 'sys',\n" + 
                    		"    `update_by` varchar (100) not null default 'sys',\n" + 
                    		"    `user_id` int not null comment 'id of table user_info',\n" + 
                    		"    `total_trips` int not null ,\n" + 
                    		"    `total_ratings` int not null ,\n" + 
                    		"    `average_rating` int not null ,\n" + 
                    		"    primary key (id),\n" + 
                    		"    constraint rating_foreign_key foreign key (`user_id`) references `user_info` (`id`)\n" + 
                    		") ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='rating table';");
                    
                    statement.execute("create table schedule(\n" + 
                    		"    `id` int not null auto_increment,\n" + 
                    		"    `create_date` DATE not null,\n" + 
                    		"    `update_date` date not null,\n" + 
                    		"    `create_by` varchar (100) not null default 'sys',\n" + 
                    		"    `update_by` varchar (100) not null default 'sys',\n" + 
                    		"    `user_id` int not null comment 'id of table user_info',\n" + 
                    		"    `start_position` varchar(256),\n" + 
                    		"    `start_position_longitude` varchar(100) not null ,\n" + 
                    		"    `start_position_latitude` varchar(100) not null ,\n" + 
                    		"    `end_position` varchar(256),\n" + 
                    		"    `end_position_longitude` varchar(100) not null ,\n" + 
                    		"    `end_position_latitude` varchar(100),\n" + 
                    		"    `weekday` int not null comment '1-7: Monday-Sunday',\n" + 
                    		"    `start_duration` date not null,\n" + 
                    		"    `end_duration` date not null ,\n" + 
                    		"    `start_duration2` date,\n" + 
                    		"    `end_duration2` date,\n" + 
                    		"    `gender_preference` int null comment '1.female 2. male',\n" + 
                    		"    `rating_preference` int null,\n" + 
                    		"    `commute_type` int null comment '1.daily commute 2.real-time commute',\n" + 
                    		"    `engage_time` timestamp null default now(),\n" + 
                    		"    `status` int not null comment '0.initialization 1.fail 2.success',\n" + 
                    		"    `current_server` varchar(100) null ,\n" + 
                    		"\n" + 
                    		"    primary key (id),\n" + 
                    		"    constraint schedule_foreign_key foreign key (`user_id`) references `user_info` (`id`)\n" + 
                    		")ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='schedule table';");
                    
                    statement.execute("create table `trip` (\n" + 
                    		"    `id` int not null auto_increment,\n" + 
                    		"    `create_date` DATE not null ,\n" + 
                    		"    `update_date` date not null,\n" + 
                    		"    `create_by` varchar (100) not null default 'sys',\n" + 
                    		"    `update_by` varchar (100) not null default 'sys',\n" + 
                    		"    `schedule_id` int not null comment 'id of schedule table',\n" + 
                    		"    `group_id` int not null,\n" + 
                    		"    `status` int not null comment '1.initialized 2.started 3.finished 4.cancelled',\n" + 
                    		"    `start_position` varchar(100) not null ,\n" + 
                    		"    `end_position` varchar(100) not null  ,\n" + 
                    		"    `weekday` int not null comment '1-7: Monday-Sunday',\n" + 
                    		"\n" + 
                    		"    primary key (id),\n" + 
                    		"    constraint trip_foreign_key foreign key (`schedule_id`) references `schedule` (`id`)\n" + 
                    		") ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='trip table';");
                    
                    System.out.println("all tables created");
                    
                    statement.close();
                }
                catch ( SQLException e )
                {
                    System.out.println( "JDBC error: " + e );
                }
                finally
                {
                    con.close();
                }
            }
            catch( SQLException e )
            {
                System.out.println( "could not get JDBC connection: " + e );
            }
        }
        catch( Exception e )
        {
            System.out.println( "could not load JDBC driver: " + e );
        }
	}

}

