package ie.tcd.ase.service.impl;

import ie.tcd.ase.dao.ScheduleMapper;
import ie.tcd.ase.dao.TripMapper;
import ie.tcd.ase.entity.Schedule;
import ie.tcd.ase.entity.ScheduleExample;
import ie.tcd.ase.entity.Trip;
import ie.tcd.ase.entity.TripExample;
import ie.tcd.ase.service.ScheduleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ScheduleServiceImpl implements ScheduleService {

    @Autowired
    private ScheduleMapper scheduleMapper;
    @Autowired
    private TripMapper tripMapper;
    @Override
    public int save(Schedule schedule) {
    	int result=scheduleMapper.insert(schedule);
    	System.out.println("result: "+result);
        return result;
    }
    
    @Override
    public int updateScheduleToSuccess(Schedule schedule) {
    	ScheduleExample example = new ScheduleExample();
        ScheduleExample.Criteria criteria = example.createCriteria();
        criteria.andStatusEqualTo(0);
        criteria.andIdEqualTo(schedule.getId());
        
        int result=scheduleMapper.updateByExample(schedule, example);
        return result;
    }
    
    @Override
    public int saveTrip(Trip trip) {
    	int result=tripMapper.insert(trip);
    	System.out.println("result: "+result);
        return result;
    }
    
	
	 @Override public List<Schedule> getScheduleList(int userId) 
	 { 
		  ScheduleExample example = new ScheduleExample(); ScheduleExample.Criteria criteria =
		  example.createCriteria(); criteria.andUserIdEqualTo(userId);
		  
		  return scheduleMapper.selectByExample(example); 
	 }
	 

	@Override
	public List<Schedule> getSchedule(Integer status) {
		ScheduleExample example = new ScheduleExample();
        ScheduleExample.Criteria criteria = example.createCriteria();
        criteria.andStatusEqualTo(status);

        return scheduleMapper.selectByExample(example);
	}
	@Override
	public List<Trip> getTrip(Integer status) {
		TripExample example = new TripExample();
		//TripExample.Criteria criteria = example.createCriteria();
        //criteria.andStatusEqualTo(status);

        return tripMapper.selectByExample(example);
	}
}
