package ie.tcd.ase.controller;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.apache.commons.collections.map.HashedMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ie.tcd.ase.entity.Schedule;
import ie.tcd.ase.service.ScheduleService;

public class Schedular implements Runnable {
	ScheduleService scheduleService;
	int timeout;
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	 
	public Schedular(ScheduleService scheduleService, int timeout) {
		super();
		this.scheduleService = scheduleService;
		this.timeout=timeout;
	}
	
	@Override
	public void run() {
        System.out.println("starting schedular with timeout period "+timeout+" seconds");
        
        try {
        	while(true) {
		        System.out.println("schedular thread with name: "+ Thread.currentThread().getName()+" woke up ");
		        
		        scheduleTrip();
		        
		        Thread.sleep(timeout*1000);
			} 
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void scheduleTrip() {
		List<Schedule> listSchedule=scheduleService.getSchedule(0);
        System.out.println("Schedule list size: "+listSchedule.size());
        
        Map<Schedule,Integer> groups=new HashedMap();
		Set<Schedule> tripDone=new HashSet<Schedule>();
		Random random=new Random();
		
		for(int i=0;i<listSchedule.size();i++) {
			Schedule currentSchedule=listSchedule.get(i);
			//skip if trip is already formed for this schedule
			if(tripDone.contains(currentSchedule)) continue;
			
			int groupMembers=0;
			int groupId=random.nextInt();
			if(groupId<0) groupId*=-1;
			for(int j=i+1;j<listSchedule.size();j++) {
				Schedule anotherSchedule=listSchedule.get(j);
				if(similar(currentSchedule,anotherSchedule)) {
					groups.put(currentSchedule, groupId);
					groups.put(anotherSchedule, groupId);
					tripDone.add(currentSchedule);
					tripDone.add(anotherSchedule);
					groupMembers++;
				}
				//maximum 2 group members for now
				if(groupMembers==2) break;
			}
			
			//to simulate different threads working, break here after forming groups
			break;
		}
		
		System.out.println("#################Groups formed##################");
        for(Schedule schedule:groups.keySet()) {
        	System.out.println(schedule);
        	System.out.println(groups.get(schedule));
        }
        System.out.println("#################Groups ends##################");
        
		//update matched schedule's status to success
		updateScheduleStatusToSuccess(tripDone);
		
        //write trips to Trip table
        writeTripsData(groups);
	}


	private boolean similar(Schedule currentSchedule, Schedule anotherSchedule) {
		if(currentSchedule.getCommuteType()!=anotherSchedule.getCommuteType()) return false;
		if(currentSchedule.getStartDuration().getDate() !=anotherSchedule.getStartDuration().getDate()) return false;
		if(currentSchedule.getStartDuration().getMonth() !=anotherSchedule.getStartDuration().getMonth()) return false;
		if(currentSchedule.getStartDuration().getYear() !=anotherSchedule.getStartDuration().getYear()) return false;
		
		return true;
	}
	
	private void updateScheduleStatusToSuccess(Set<Schedule> tripDone) {
		for(Schedule schedule:tripDone) {
			schedule.setStatus(2);
			scheduleService.updateScheduleToSuccess(schedule);
		}
	}
	
	private void writeTripsData(Map<Schedule, Integer> groups) {
		// TODO Auto-generated method stub
		//to be developed by Baolei
	}
}
