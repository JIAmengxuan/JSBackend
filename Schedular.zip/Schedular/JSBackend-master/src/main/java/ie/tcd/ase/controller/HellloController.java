package ie.tcd.ase.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import ie.tcd.ase.entity.Schedule;
import ie.tcd.ase.service.ScheduleService;

import java.util.HashSet;
import java.util.List;

import javax.annotation.PostConstruct;

@Controller
@RequestMapping("/controller")
public class HellloController {
	
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    @Autowired
    ScheduleService scheduleService;
    
    @RequestMapping(value = "/hello", method = RequestMethod.GET)
    @ResponseBody
    public String helloWorld() {
        logger.info("Entered hello world controller");
        
        return "hello controller";
    }
    
    @RequestMapping(value = "/enterDummyData", method = RequestMethod.GET)
    @ResponseBody
    public String enterDummyData() {
        System.out.println("enter dummy data");
        
        //resetDataBase. drop schedule and tripdata
		MyClass.reset();
		
		//eter new data
		for(Schedule schedule:DummyData.dummyScheduleList) 
		{ 	
			System.out.println("inserting dummy schedule");
			System.out.println(schedule);
			scheduleService.save(schedule);
		} 
		
		return "dummy data saved";
    }
    
    @RequestMapping(value = "/startSchedular/{timeOut}", method = RequestMethod.GET)
    @ResponseBody
    public String startSchedular(@PathVariable int timeOut) {
        System.out.println("starting schedular");	
        
		//start schedular
		new Thread(new Schedular(scheduleService, timeOut), "ThreadName"+timeOut).start();
		
		return "schedular started";
    }
    
}

