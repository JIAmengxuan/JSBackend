TCD.ASE.Group7
JourneySharing backend part.

http://localhost:8080/Schedular/controller/hello
http://localhost:8080/Schedular/controller/enterDummyData
localhost:8080/Schedular/controller/startSchedular/60
