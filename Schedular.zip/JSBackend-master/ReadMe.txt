TCD.ASE.Group7
JourneySharing backend part.

http://localhost:8080/Schedular/controller/hello
http://localhost:8080/Schedular/controller/enterDummyData
http://localhost:8080/Schedular/controller/startSchedular/thread2/13

mysql -u group7user1 -h 35.241.150.114 -p

select id,user_id,start_position,end_position,weekday,start_duration,gender_preference,rating_preference,commute_type,status,current_server from schedule;
select * from trip;

group7password1
