package ie.tcd.ase.controller;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import ie.tcd.ase.entity.Schedule;

public class Group {
	private Set<Schedule> groupMembers=new HashSet<Schedule>();
	private String startPosition;
	private String startTime;
	public Set<Schedule> getGroupMembers() {
		return groupMembers;
	}
	public void setGroupMembers(Set<Schedule> groupMembers) {
		this.groupMembers = groupMembers;
	}
	
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getStartPosition() {
		return startPosition;
	}
	public void setStartPosition(String startPosition) {
		this.startPosition = startPosition;
	}
	@Override
	public String toString() {
		return "Group [groupMembers=" + groupMembers + ", startPosition=" + startPosition + ", startTime=" + startTime
				+ "]";
	}
	
	
	
}
