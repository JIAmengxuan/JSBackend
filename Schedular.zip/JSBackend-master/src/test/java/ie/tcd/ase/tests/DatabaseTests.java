package ie.tcd.ase.tests;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ie.tcd.ase.controller.DummyData;
import ie.tcd.ase.entity.Schedule;
import ie.tcd.ase.service.ScheduleService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:spring/*.xml")
public class DatabaseTests {
	@Autowired
	ScheduleService scheduleService;
	
	@Test
	public void testDatabaseConnection() throws Exception {
		Class.forName( "com.mysql.jdbc.Driver" ).newInstance();
        Connection con = DriverManager.getConnection( "jdbc:mysql://35.241.150.114/journeySharing", "group7user1", "group7password1" );
        Statement statement = con.createStatement();
	}
	
	@Test
	public void testDatabaseUsersAvailability() throws Exception {
		Class.forName( "com.mysql.jdbc.Driver" ).newInstance();
        Connection con = DriverManager.getConnection( "jdbc:mysql://35.241.150.114/journeySharing", "group7user1", "group7password1" );
        Statement statement = con.createStatement();
        ResultSet resultSet= statement.executeQuery("select  * from user_info");
        assertNotEquals(1, resultSet.getFetchSize());
	}
	
	@Test
	public void testSampleDataInsertion() throws Exception {
		Schedule schedule=DummyData.dummyScheduleList.get(0);
		System.out.println("inserting dummy schedule");
		System.out.println(schedule);
		scheduleService.save(schedule);
		
		List<Schedule> scheduleList=scheduleService.getSchedule( schedule.getStatus() );
		assertTrue( scheduleList.contains(schedule) );
	}
}
